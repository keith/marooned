require "optparse"
require "pathname"

require "xcodeproj"

require "marooned/cli"
require "marooned/finder"
require "marooned/marooned_exception"
require "marooned/project"
require "marooned/runner"
require "marooned/version"
