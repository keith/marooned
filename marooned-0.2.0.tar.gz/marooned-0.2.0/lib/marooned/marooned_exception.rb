class MaroonedException < Exception
end
