module Marooned
  VERSION = "0.1.2"
end
